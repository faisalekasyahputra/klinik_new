-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: klinikpkp
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bendung`
--

DROP TABLE IF EXISTS `bendung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bendung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `NO_permen` varchar(255) DEFAULT NULL,
  `NAMA_DI` varchar(255) DEFAULT NULL,
  `id_di` int(11) NOT NULL,
  `STATUS_IRI` varchar(255) DEFAULT NULL,
  `KABUPATEN` varchar(255) DEFAULT NULL,
  `KECAMATAN` varchar(255) DEFAULT NULL,
  `DESA` varchar(255) DEFAULT NULL,
  `id_desa` int(11) DEFAULT NULL,
  `X` varchar(255) DEFAULT NULL,
  `Y` varchar(255) DEFAULT NULL,
  `TAHUN_SELE` varchar(255) DEFAULT NULL,
  `LUAS_AREAL` varchar(255) DEFAULT NULL,
  `BAKU` varchar(255) DEFAULT NULL,
  `POTENSIAL` varchar(255) DEFAULT NULL,
  `FUNGSIONAL` varchar(255) DEFAULT NULL,
  `F_Alasan_p` varchar(255) DEFAULT NULL,
  `UPTD` varchar(255) DEFAULT NULL,
  `NAMA_BENDU` varchar(255) DEFAULT NULL,
  `KEMANTREN` varchar(255) DEFAULT NULL,
  `geojson` varchar(255) DEFAULT NULL,
  `Photo1` varchar(255) DEFAULT NULL,
  `KONDISI` varchar(255) DEFAULT NULL,
  `Photo2` varchar(255) DEFAULT NULL,
  `Photo3` varchar(255) DEFAULT NULL,
  `nomenklatur` varchar(255) DEFAULT NULL,
  `id_kemantren` int(11) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=632 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_room_id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_token` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT 'bot',
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `irigasi`
--

DROP TABLE IF EXISTS `irigasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irigasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `K_SALURAN` varchar(255) DEFAULT NULL,
  `NOMENKLATU` varchar(255) DEFAULT NULL,
  `NAMA` varchar(255) DEFAULT NULL,
  `DI` varchar(255) DEFAULT NULL,
  `KelasSalur` varchar(255) DEFAULT NULL,
  `id_di` varchar(255) DEFAULT NULL,
  `PANJANG` varchar(255) DEFAULT NULL,
  `Kode_DI` varchar(255) DEFAULT NULL,
  `Desa` varchar(255) DEFAULT NULL,
  `id_desa` varchar(255) DEFAULT NULL,
  `Kecamatan` varchar(255) DEFAULT NULL,
  `NO_DI` varchar(255) DEFAULT NULL,
  `UPTD` varchar(255) DEFAULT NULL,
  `KONDISI` varchar(255) DEFAULT NULL,
  `KEMANTREN` varchar(255) DEFAULT NULL,
  `Photo_Awal` varchar(255) DEFAULT NULL,
  `Photo_Ujun` varchar(255) DEFAULT NULL,
  `geojson` longtext DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1304 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kondisi`
--

DROP TABLE IF EXISTS `kondisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kondisi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `K_SALURAN` varchar(255) DEFAULT NULL,
  `NOMENKLATU` varchar(255) DEFAULT NULL,
  `NAMA` varchar(255) DEFAULT NULL,
  `DI` varchar(255) DEFAULT NULL,
  `KelasSalur` varchar(255) DEFAULT NULL,
  `Desa` varchar(255) DEFAULT NULL,
  `Kecamatan` varchar(255) DEFAULT NULL,
  `NO_DI` varchar(255) DEFAULT NULL,
  `UPTD` varchar(255) DEFAULT NULL,
  `KONDISI` varchar(255) DEFAULT NULL,
  `KEMANTREN` varchar(255) DEFAULT NULL,
  `HM` varchar(255) DEFAULT NULL,
  `Id_Saluran` varchar(255) DEFAULT NULL,
  `geojson` longtext DEFAULT NULL,
  `tinggikiri` float DEFAULT NULL,
  `tebalkiri` float DEFAULT NULL,
  `tinggikanan` float DEFAULT NULL,
  `tebalkanan` float DEFAULT NULL,
  `konstruksikiri` varchar(255) DEFAULT NULL,
  `konstruksikanan` varchar(225) DEFAULT NULL,
  `lebaratas` float DEFAULT NULL,
  `lebarbawah` float DEFAULT NULL,
  `tahun` varchar(255) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `folder` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11384 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi`
--

DROP TABLE IF EXISTS `multi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saluran_pembuang`
--

DROP TABLE IF EXISTS `saluran_pembuang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saluran_pembuang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_saluran` varchar(255) DEFAULT NULL,
  `Kecamatan` varchar(255) DEFAULT NULL,
  `Desa` varchar(255) DEFAULT NULL,
  `Kemantren` varchar(255) DEFAULT NULL,
  `UPTD` varchar(255) DEFAULT NULL,
  `id_uptd` varchar(255) DEFAULT NULL,
  `Kondisi` varchar(255) DEFAULT NULL,
  `foto_awal` varchar(255) DEFAULT NULL,
  `foto_ujung` varchar(255) DEFAULT NULL,
  `nomenklatur` varchar(255) DEFAULT NULL,
  `no_sk` int(11) DEFAULT NULL,
  `PANJANG` float DEFAULT NULL,
  `LEBAR_A` float DEFAULT NULL,
  `LEBAR_B` float DEFAULT NULL,
  `TINGGI_KI` float DEFAULT NULL,
  `TEBAL_KI` float DEFAULT NULL,
  `MATRIAL_KI` varchar(255) DEFAULT NULL,
  `TINGGI_KA` float DEFAULT NULL,
  `TEBAL_KA` float DEFAULT NULL,
  `MATRIAL_KA` varchar(255) DEFAULT NULL,
  `TAHUN_DATA` varchar(255) DEFAULT NULL,
  `Keterangan` varchar(255) DEFAULT NULL,
  `MANTRI` varchar(255) DEFAULT NULL,
  `geojson` longtext DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1019 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sosmed_perumahan`
--

DROP TABLE IF EXISTS `sosmed_perumahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sosmed_perumahan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_perumahan` varchar(255) DEFAULT NULL,
  `pengembang` varchar(255) DEFAULT NULL,
  `kabupaten_kota` varchar(100) DEFAULT NULL,
  `asosiasi` varchar(100) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_diskusi`
--

DROP TABLE IF EXISTS `tb_diskusi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_diskusi` (
  `id_diskusi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(255) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `judul_topik` varchar(255) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `isi_diskusi` text NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('open','resolved','closed') DEFAULT 'open',
  `is_deleted` tinyint(1) DEFAULT 0,
  `report_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `like_count` int(11) DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id_diskusi`),
  KEY `idx_status` (`status`),
  KEY `idx_kategori` (`kategori`),
  KEY `idx_is_deleted` (`is_deleted`),
  KEY `idx_user_id_d` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_forum_likes`
--

DROP TABLE IF EXISTS `tb_forum_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_forum_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `target_type` enum('diskusi','komentar') NOT NULL,
  `target_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_target` (`user_id`,`target_type`,`target_id`),
  KEY `idx_target` (`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_komentar`
--

DROP TABLE IF EXISTS `tb_komentar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `id_diskusi` int(11) NOT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `nama_komentator` varchar(255) NOT NULL,
  `isi_komentar` text NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `report_count` int(11) DEFAULT 0,
  `like_count` int(11) DEFAULT 0,
  `role` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id_komentar`),
  KEY `idx_is_del_k` (`is_deleted`),
  KEY `idx_user_id_k` (`user_id`),
  KEY `idx_reply_to` (`reply_to`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `file_foto` varchar(255) DEFAULT NULL,
  `bidang` varchar(255) DEFAULT NULL,
  `kategori` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_documents`
--

DROP TABLE IF EXISTS `user_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doc_type` varchar(50) NOT NULL COMMENT 'ktp, siup_nib, ktm, surat_magang, surat_ijin_usaha',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) NOT NULL DEFAULT 0,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_documents_user_id` (`user_id`),
  CONSTRAINT `fk_user_documents_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_token` varchar(64) DEFAULT NULL,
  `email_token_expiry` datetime DEFAULT NULL,
  `role` varchar(30) DEFAULT NULL,
  `profile_completed` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'restricted',
  `login_attempts` tinyint(4) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `nik` text DEFAULT NULL,
  `nik_lookup_hash` varchar(64) DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `idx_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'klinikpkp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-09 12:59:08
